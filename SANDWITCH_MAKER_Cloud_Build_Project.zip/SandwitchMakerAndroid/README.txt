SANDWITCH MAKER - ANDROID PROJECT
=================================

This is an Android Studio project source package, not a prebuilt APK.

WHAT IT DOES
- Shows the SANDWITCH MAKER menu:
  Veg Sandwich ₹40
  Egg Sandwich ₹59
  Paneer Sandwich ₹69
  Chicken Sandwich ₹79
  Egg Cheese Sandwich ₹89
  Cheese Chicken Sandwich ₹109
  Chai ₹10
  Boiled Eggs ₹12
- Lets customers add/remove items and calculates the total.
- Collects customer name, phone, and delivery/pickup details.
- Opens WhatsApp with the order message addressed to +91 97486 05634.
- Customers must press Send in WhatsApp to submit the order.

BUILD AN APK
1. Install Android Studio on a Windows/Mac/Linux computer.
2. Extract this ZIP file.
3. In Android Studio choose File > Open and select the extracted
   SandwitchMaker folder (the folder containing settings.gradle.kts).
4. Allow Gradle sync and install Android SDK Platform 35 if prompted.
5. Select Build > Build Bundle(s) / APK(s) > Build APK(s).
6. When complete, choose "locate" in the notification. The APK is usually:
   app/build/outputs/apk/debug/app-debug.apk
7. Transfer that APK to your Android phone and install it. You may need
   to allow installation from that source in Android settings.

NOTES
- This project needs Android Studio and Android SDK to compile.
- No payment gateway, server-side order database, or live order dashboard
  is included. Orders are sent as prepared WhatsApp messages.
- The app does not collect or store customer information on a server.
